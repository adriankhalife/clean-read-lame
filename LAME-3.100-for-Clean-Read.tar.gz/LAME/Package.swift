// swift-tools-version: 6.0
//
// LAME 3.100, the MP3 encoder (libmp3lame only), packaged for VoiceEditor.
// LAME is licensed under the GNU LGPL (see COPYING and LICENSE). It is built as its own
// dynamic library, separate from the app, as the LGPL asks. Source: https://lame.sourceforge.io
//
import PackageDescription

let package = Package(
    name: "LAME",
    platforms: [.iOS(.v18)],
    products: [
        .library(name: "LAME", type: .dynamic, targets: ["LAME"]),
    ],
    targets: [
        .target(
            name: "LAME",
            path: "Sources/LAME",
            cSettings: [
                .define("HAVE_CONFIG_H"),
                .define("NDEBUG"),
                .headerSearchPath("."),
                .headerSearchPath("include"),
                // LAME's own code, untouched: its old-style warnings are not ours to fix
                .unsafeFlags(["-w"]),
            ]
        ),
    ]
)
