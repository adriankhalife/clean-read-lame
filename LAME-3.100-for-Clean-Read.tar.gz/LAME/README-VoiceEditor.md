# LAME in VoiceEditor

- Version: LAME 3.100 (lame-3.100.tar.gz from SourceForge, SHA-256 ddfe36cab873794038ae2c1210557ad34857a4b6bdc515785d1da9e175b1da1e).
- Only the encoder library (libmp3lame) is included, unmodified, plus a hand-written config.h.
- License: GNU Lesser General Public License (COPYING, LICENSE). Built as a separate dynamic library.
- Before publishing: show the LAME notice and license in the app (About / Acknowledgements) and say where to get the source.
